##################################
function setup_input_data() {
# here we create the input data we want to work with.

# pcrf stream..
rm -fr pcrf_stream.txt
Time1=$(date --date='52 hours ago' +"%Y-%m-%d %T")
Time2=$(date --date='25 hours ago' +"%Y-%m-%d %T"); 
Time2=
Time3=$(date --date='2 seconds ago' +"%Y-%m-%d %T"); 
Time3=hi
Quota_Next_Reset_Time1=$(date --date='16 days' +"%Y-%m-%d %T")
echo "2,$Time1,,,4912345678901,,,,,,,,,0,,,,,,1.2.3.4,,,,,,,Q_110_local_Month,6,12,,,1024,$Quota_Next_Reset_Time1,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,1" >> pcrf_stream.txt
echo "2,$Time2,,,4912345678902,,,,,,,,,0,,,,,,1.2.3.4,,,,,,,Q_110_local_Month,6,12,,,1024,$Quota_Next_Reset_Time1,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,1" >> pcrf_stream.txt
echo "2,$Time3,,,4912345678903,,,,,,,,,0,,,,,,1.2.3.4,,,,,,,Q_110_local_Month,6,12,,,1024,$Quota_Next_Reset_Time1,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,1" >> pcrf_stream.txt

## we just change the number range for prepaid entries..
#echo "2,$Time1,,,4922345678901,,,,,,,,,0,,,,,,1.2.3.4,,,,,,,Q_110_local_Month,6,12,,,1024,$Quota_Next_Reset_Time1,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,1" >> pcrf_stream.txt
#echo "2,$Time2,,,4922345678902,,,,,,,,,0,,,,,,1.2.3.4,,,,,,,Q_110_local_Month,6,12,,,1024,$Quota_Next_Reset_Time1,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,1" >> pcrf_stream.txt
#echo "2,$Time3,,,4922345678903,,,,,,,,,0,,,,,,1.2.3.4,,,,,,,Q_110_local_Month,6,12,,,1024,$Quota_Next_Reset_Time1,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,1" >> pcrf_stream.txt

echo "############################"
echo "preparing pcrf stream.."
rm -fr pcrf_stream.csv
touch pcrf_stream.csv
cnt=0
max_cnt=$(wc -l pcrf_stream.txt| awk '{print $1}')
while [ "$cnt" -ne "$max_cnt" ]
do
#  echo "cnt=$cnt"
  cnt=$(( $cnt + 1 ))
  myline=$(head -${cnt} pcrf_stream.txt|tail -1)
  echo "i,n,$myline,${cnt}" >> pcrf_stream.csv
done
echo "############################"

# payment type for postpaid..
rm -fr payment_type_postpaid.txt
echo "4912345678901,POSTPAID" >> payment_type_postpaid.txt
echo "4912345678902,POSTPAID" >> payment_type_postpaid.txt
echo "4912345678903,POSTPAID" >> payment_type_postpaid.txt


echo "############################"
echo "preparing payment type lkp.."
rm -fr payment_type_postpaid.csv
cnt=0
max_cnt=$(wc -l payment_type_postpaid.txt| awk '{print $1}')
while [ "$cnt" -ne "$max_cnt" ]
do
#  echo "cnt=$cnt"
  cnt=$(( $cnt + 1 ))
  myline=$(head -${cnt} payment_type_postpaid.txt|tail -1)
  echo "p,n,$myline" >> payment_type_postpaid.csv
done
touch payment_type_postpaid.csv.done
echo "############################"


# payment type for prepaid..
rm -fr payment_type_prepaid.txt
echo "4922345678901,PREPAID" >> payment_type_prepaid.txt
echo "4922345678902,PREPAID" >> payment_type_prepaid.txt
echo "4922345678903,PREPAID" >> payment_type_prepaid.txt


echo "############################"
echo "preparing payment type lkp.."
rm -fr payment_type_prepaid.csv 
cnt=0
max_cnt=$(wc -l payment_type_prepaid.txt| awk '{print $1}')
while [ "$cnt" -ne "$max_cnt" ]
do
#  echo "cnt=$cnt"
  cnt=$(( $cnt + 1 ))
  myline=$(head -${cnt} payment_type_prepaid.txt|tail -1)
  echo "p,n,$myline" >> payment_type_prepaid.csv
done
touch payment_type_prepaid.csv.done
echo "############################"

}
##################################
function kill_cep() {
  for i in $(ps aux |grep -i dfesp_xml_server|grep -v grep|awk '{print $2}')
  do
    if [ $(echo $i|wc -w) -ne 0 ]
    then
      echo "killing cep server $i"
      kill -9 $i
    fi
  done

  for i in $(ps aux |grep -i streamviewer|grep -v grep|awk '{print $2}')
  do
    if [ $(echo $i|wc -w) -ne 0 ]
    then
      echo "killing cep streamviewer $i"
      kill -9 $i
    fi
  done
}
##################################

kill_cep
setup_input_data

echo "############################"
echo "starting the cep server"
$DFESP_HOME/bin/dfesp_xml_server -pubsub 55555 -server 55556 -loglevel debug -badevents bad_events.log &
echo "sleep 2"
sleep 2
echo "############################"

echo "############################"
echo "starting POSTPAID_THROTTLE_EVENT_load"
$DFESP_HOME/bin/dfesp_xml_client -server localhost:55556 -file POSTPAID_THROTTLE_EVENT_load.xml &
echo "sleep 2"
sleep 2
echo "############################"

echo "############################"
echo "starting POSTPAID_THROTTLE_EVENT_start"
$DFESP_HOME/bin/dfesp_xml_client -server localhost:55556 -file POSTPAID_THROTTLE_EVENT_start.xml &
echo "sleep 2"
sleep 2
echo "############################"


mylist=$(echo $mylist dfESP://localhost:55555/POSTPAID_THROTTLE_EVENT/THROTTLE_EVENT_QUERY/PCRF_DATA_USAGE_STREAM)
mylist=$(echo $mylist dfESP://localhost:55555/POSTPAID_THROTTLE_EVENT/THROTTLE_EVENT_QUERY/PAIDTYPE_SOURCE_LOOKUP)
mylist=$(echo $mylist dfESP://localhost:55555/POSTPAID_THROTTLE_EVENT/THROTTLE_EVENT_QUERY/REQUIRRING_TYPE_SOURCE_LOOKUP)
mylist=$(echo $mylist dfESP://localhost:55555/POSTPAID_THROTTLE_EVENT/THROTTLE_EVENT_QUERY/FILTER_THROTTLE_EVENT_100)
mylist=$(echo $mylist dfESP://localhost:55555/POSTPAID_THROTTLE_EVENT/THROTTLE_EVENT_QUERY/COPY_DATA_VOLUME_USED_IN_LAST_48_HOURS)
mylist=$(echo $mylist dfESP://localhost:55555/POSTPAID_THROTTLE_EVENT/THROTTLE_EVENT_QUERY/AGGR_DATA_VOLUME_USED_IN_LAST_48_HOURS)
mylist=$(echo $mylist dfESP://localhost:55555/POSTPAID_THROTTLE_EVENT/THROTTLE_EVENT_QUERY/ADD_DATA_VOLUME_USED_IN_LAST_48_HOURS)
mylist=$(echo $mylist dfESP://localhost:55555/POSTPAID_THROTTLE_EVENT/THROTTLE_EVENT_QUERY/ADD_PAIDTYPE)
mylist=$(echo $mylist dfESP://localhost:55555/POSTPAID_THROTTLE_EVENT/THROTTLE_EVENT_QUERY/FILTER_PCRF_DATA_USAGE)
mylist=$(echo $mylist dfESP://localhost:55555/POSTPAID_THROTTLE_EVENT/THROTTLE_EVENT_QUERY/ADD_REQUIRRING)
echo "mylist=$mylist"

echo "############################"
echo "starting stream viewer.."
java -classpath $DFESP_HOME/lib/dfx-esp-streamviewer.jar:$DFESP_HOME/lib/dfx-esp-api.jar streamviewer.StreamViewer $mylist -initialX 1 -initialY 1 -height 800 -width 600 -height 750 -width 1400 &
echo "sleep 6"
sleep 6
echo "############################"

echo "############################"
echo "feeding in payment type.."
$DFESP_HOME/bin/dfesp_fs_adapter -Q -k pub -h "dfESP://localhost:55555/POSTPAID_THROTTLE_EVENT/THROTTLE_EVENT_QUERY/PAIDTYPE_SOURCE_LOOKUP" -b 1 -t csv -f payment_type_postpaid.csv
echo "sleep 2"
sleep 2
echo "############################"

echo "############################"
echo "feeding in pcrf stream.."
$DFESP_HOME/bin/dfesp_fs_adapter -Q -k pub -h "dfESP://localhost:55555/POSTPAID_THROTTLE_EVENT/THROTTLE_EVENT_QUERY/PCRF_DATA_USAGE_STREAM" -b 1 -t csv -f pcrf_stream.csv
echo "sleep 2"
sleep 2
echo "############################"


